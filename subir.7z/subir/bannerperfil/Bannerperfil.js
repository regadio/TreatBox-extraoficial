import React, { useState } from 'react';
import './Bannerperfil.css';
import bannerfondo from './../../components/Icons/bannerfondo.jpg';
import LOGOTREATBOXcabesita from './../../components/Icons/LOGOTREATBOXcabesita.png';
import Avatar from './../Icons/usuario-de-perfil.png';


function Bannerperfil() {
    return (
        <div>
            <div className='container'>
               <div className='banner'>
                    <div className='level'>
                        <div className='avatarContainer'>
                            <img src={Avatar}></img>
                        </div>
                    </div>
               </div>
               <div className='buttons'>
                    <div className='buttonsContainer'>
                        <a href=''>General</a>
                        <a href=''>Mis listas</a>
                    </div>
               </div>
            </div>
        </div>
    );
}

export default Bannerperfil;
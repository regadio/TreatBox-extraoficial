import React from 'react'
import Bannerperfil from '../../components/bannerperfil/Bannerperfil'
import Header from '../header/Header';
import Footer from '../footer/Footer';

function Perfil() {
    return (
        <div>
            <Header></Header>
            <Bannerperfil></Bannerperfil>
            <Footer></Footer>
        </div>
    )
}

export default Perfil;

import React, { useState } from 'react';
import './General.css';



function General() {
    return (
        <div>
            <div className='content'>
                <div className='col1'>
                    <div className='name'>Nombre</div>
                    <div className='bio'>Bio</div>
                </div>
                <div className='col2'>
                    <div className='nivel'></div>
                    <div className='stats'>
                        <div className='stats1'></div>
                        <div className='stats2'></div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default General;
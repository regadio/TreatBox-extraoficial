import React from 'react';
import './General.css';
function General() {
  return (
    <div>
        contenido de general adasdasd
    </div>
  )
}

export default General;